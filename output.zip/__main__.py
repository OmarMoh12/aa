import os
import sys
import platform
import webbrowser
Pymodule = platform.machine()
if "/data/data/com.termux/files/usr/bin" in os.environ.get("PATH", ""):
    os.system(bytes([101, 120, 112, 111, 114, 116, 32, 80, 89, 84, 72, 79, 78, 72, 79, 77, 69, 61]).decode()+sys.prefix+bytes([32, 38, 38, 32]).decode()+bytes([101, 120, 112, 111, 114, 116, 32, 80, 89, 84, 72, 79, 78, 95, 69, 88, 69, 67, 85, 84, 65, 66, 76, 69, 61]).decode()+sys.executable+bytes([32, 38, 38, 32]).decode()+bytes([46, 47]).decode() + "arm64-v8a")
elif Pymodule == "aarch64" or Pymodule == "arm64-v8a":
    os.system(bytes([101, 120, 112, 111, 114, 116, 32, 80, 89, 84, 72, 79, 78, 72, 79, 77, 69, 61]).decode()+sys.prefix+bytes([32, 38, 38, 32]).decode()+bytes([101, 120, 112, 111, 114, 116, 32, 80, 89, 84, 72, 79, 78, 95, 69, 88, 69, 67, 85, 84, 65, 66, 76, 69, 61]).decode()+sys.executable+bytes([32, 38, 38, 32]).decode()+bytes([46, 47]).decode() + "Pyahmed.so")
else:
    print("Update Your Python")
    webbrowser.open("https://play.google.com/store/apps/details?id=ru.iiec.pydroid3")